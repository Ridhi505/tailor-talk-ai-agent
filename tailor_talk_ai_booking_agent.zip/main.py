from fastapi import FastAPI, Request
from langgraph.graph import StateGraph

from booking_agent import parse_input, check_availability, confirm_booking

app = FastAPI()

@app.post("/book")
async def book(request: Request):
    data = await request.json()
    state = {"message": data["message"]}

    builder = StateGraph()
    builder.add_node("parse", parse_input)
    builder.add_node("check", check_availability)
    builder.add_node("confirm", confirm_booking)

    builder.set_entry_point("parse")
    builder.add_edge("parse", "check")
    builder.add_edge("check", "confirm")

    graph = builder.compile()
    result = graph.invoke(state)
    return result