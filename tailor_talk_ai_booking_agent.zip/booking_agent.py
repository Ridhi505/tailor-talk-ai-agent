def parse_input(state):
    message = state["message"]
    if "book" in message.lower():
        return {"intent": "book_appointment", "message": message}
    return {"intent": "unknown", "message": message}

def check_availability(state):
    if state.get("intent") == "book_appointment":
        # Stub logic: Always available
        return {**state, "available": True, "slot": "Monday 10AM"}
    return {**state, "available": False}

def confirm_booking(state):
    if state.get("available"):
        # In real scenario, call Google Calendar API here.
        confirmation = f"Appointment confirmed for {state['slot']}."
        return {**state, "confirmation": confirmation}
    return {**state, "confirmation": "Sorry, no availability."}