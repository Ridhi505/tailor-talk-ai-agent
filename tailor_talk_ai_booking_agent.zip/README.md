# Tailor Talk AI Booking Agent

A simple conversational agent built with FastAPI and LangGraph that simulates checking availability and booking an appointment.

## Running Locally

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the server:
```
uvicorn main:app --reload
```

3. Make a POST request to `/book` with JSON:
```json
{
  "message": "I want to book an appointment"
}
```

## Note

The current version mocks the calendar check. You can replace the `confirm_booking` logic in `booking_agent.py` with actual Google Calendar API calls.